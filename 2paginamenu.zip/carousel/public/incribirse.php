<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscripción en Artes Marciales</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: auto;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<h1>Inscripción en Artes Marciales</h1>

<form action="procesar_inscripcion.php" method="POST">
    <label for="nombre">Nombre Completo:</label>
    <input type="text" id="nombre" name="nombre" required>

    <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
    <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>

    <label for="genero">Género:</label>
    <select id="genero" name="genero" required>
        <option value="masculino">Masculino</option>
        <option value="femenino">Femenino</option>
        <option value="otro">Otro</option>
    </select>

    <label for="telefono">Teléfono de Contacto:</label>
    <input type="tel" id="telefono" name="telefono" required>

    <label for="correo">Correo Electrónico:</label>
    <input type="email" id="correo" name="correo" required>

    <label for="arte_marcial">Seleccione su Arte Marcial:</label>
    <select id="arte_marcial" name="arte_marcial" required>
        <option value="karate">Karate</option>
        <option value="judo">Judo</option>
        <option value="taekwondo">Taekwondo</option>
        <option value="boxeo">Boxeo</option>
        <option value="muay_thai">Muay Thai</option>
        <option value="capoeira">Capoeira</option>
    </select>

    <label>Experiencia en Artes Marciales:</label>
    <select name="experiencia" required>
        <option value="principiante">Principiante</option>
        <option value="intermedio">Intermedio</option>
        <option value="avanzado">Avanzado</option>
    </select>

    <label>
        <input type="checkbox" name="acepto" required>
        Acepto los términos y condiciones.
    </label>

    <button type="submit">Inscribirse</button>
</form>

</body>
</html>

