<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tipos de Artes Marciales</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .artes-marciales {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .arte {
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 15px;
            margin: 10px;
            width: 200px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<h1>Tipos de Artes Marciales</h1>

<div class="artes-marciales">
    <div class="arte">
        <img src="https://via.placeholder.com/200" alt="Karate">
        <h2>Karate</h2>
        <p>Un arte marcial japonés que se enfoca en técnicas de golpeo.</p>
    </div>
    
    <div class="arte">
        <img src="https://via.placeholder.com/200" alt="Judo">
        <h2>Judo</h2>
        <p>Un arte marcial japonés centrado en lanzamientos y agarres.</p>
    </div>

    <div class="arte">
        <img src="https://via.placeholder.com/200" alt="Taekwondo">
        <h2>Taekwondo</h2>
        <p>Un arte marcial coreano famoso por sus técnicas de patadas.</p>
    </div>

    <div class="arte">
        <img src="https://via.placeholder.com/200" alt="Boxeo">
        <h2>Boxeo</h2>
        <p>Un deporte de combate que se centra en el golpeo con los puños.</p>
    </div>

    <div class="arte">
        <img src="https://via.placeholder.com/200" alt="Muay Thai">
        <h2>Muay Thai</h2>
        <p>El arte marcial tailandés conocido como "el arte de los ocho miembros".</p>
    </div>

    <div class="arte">
        <img src="https://via.placeholder.com/200" alt="Capoeira">
        <h2>Capoeira</h2>
        <p>Una mezcla de danza y arte marcial brasileño.</p>
    </div>
</div>

</body>
</html>
