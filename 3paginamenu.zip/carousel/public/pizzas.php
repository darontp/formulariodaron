<title>Venta de Pizzas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .menu {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .pizza-item {
            display: flex;
            align-items: center;
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 15px;
            margin: 10px;
            width: 80%;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .pizza-item img {
            width: 100px;
            height: auto;
            border-radius: 5px;
            margin-right: 15px;
        }
        .pizza-description {
            flex-grow: 1;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<h1>Venta de Pizzas</h1>

<div class="menu">
    <div class="pizza-item">
        <img src="img/pizza-margarita.img" alt="Pizza Margarita">
        <div class="pizza-description">
            <h2>Pizza Margarita</h2>
            <p>Tomate, mozzarella y albahaca fresca.</p>
            <button>Agregar al carrito</button>
        </div>
    </div>

    <div class="pizza-item">
        <link rel="stylesheet" href="i">
        <img src="img/pizza-de-peperoni.webp" alt="Pizza Pepperoni">
        <div class="pizza-description">
            <h2>Pizza Pepperoni</h2>
            <p>Tomate, mozzarella y rodajas de pepperoni.</p>
            <button>Agregar al carrito</button>
        </div>
    </div>

    <div class="pizza-item">
        <img src="img/Pizza-cuatro-quesos-shutterstock_1514858234.webp" alt="Pizza Cuatro Quesos">
        <div class="pizza-description">
            <h2>Pizza Cuatro Quesos</h2>
            <p>Una mezcla deliciosa de cuatro tipos de queso.</p>
            <button>Agregar al carrito</button>
        </div>
    </div>

    <div class="pizza-item">
        <img src="img/a17cd68660e0-pizza-hawaiana-t.avif" alt="Pizza Hawaiana">
        <div class="pizza-description">
            <h2>Pizza Hawaiana</h2>
            <p>Tomate, mozzarella, jamón y piña.</p>
            <button>Agregar al carrito</button>
        </div>
    </div>

    <div class="pizza-item">
        <img src="img/vegetariana.jpg" alt="Pizza Vegetariana">
        <div class="pizza-description">
            <h2>Pizza Vegetariana</h2>
            <p>Tomate, mozzarella y una variedad de verduras frescas.</p>
            <button>Agregar al carrito</button>
        </div>
    </div>
</div>

</body>
